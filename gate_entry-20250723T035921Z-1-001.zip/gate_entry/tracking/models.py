
import json
import numpy as np
from django.db import models
from face_recognition import face_encodings
from django.core.files.base import ContentFile

class FacultyEntry(models.Model):
    GATE_CHOICES = [
        ('in', 'In'),
        ('out', 'Out'),
    ]

    PURPOSE_CHOICES = [
        ('lunch', 'Lunch'),
        ('bank', 'Bank'),
        ('meeting', 'Meeting'),
        ('other', 'Other'),
    ]

    DEPARTMENT_CHOICES = [
        ('cse', 'Computer Science & Engineering'),
        ('ece', 'Electronics & Communication Engineering'),
        ('eee', 'Electrical & Electronics Engineering'),
        ('mech', 'Mechanical Engineering'),
        ('civil', 'Civil Engineering'),
        ('ai&ds', 'Artificial Intelligence and Data Science'),
        ('csbs', 'Computer Science and Business System'),
        ('it', 'Information Technology'),
    ]

    faculty_name = models.CharField(max_length=100)
    staff_id = models.CharField(max_length=20)
    department = models.CharField(max_length=10, choices=DEPARTMENT_CHOICES)
    gate_entry = models.CharField(max_length=3, choices=GATE_CHOICES)
    purpose = models.CharField(max_length=20, choices=PURPOSE_CHOICES, blank=True, null=True)
    custom_purpose = models.CharField(max_length=255, blank=True, null=True)
    entry_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.staff_id} - {self.faculty_name}"
        


import json
import numpy as np
from django.db import models
from face_recognition import face_encodings
from django.core.files.base import ContentFile

class FacultyFaceEntry(models.Model):
    faculty_name = models.CharField(max_length=100)
    staff_id = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=10, choices=FacultyEntry.DEPARTMENT_CHOICES)
    photo = models.ImageField(upload_to='faculty_photos/')
    encoding = models.TextField()  # store JSON-serialized encoding
    created_at = models.DateTimeField(auto_now_add=True)

    def get_encoding_array(self):
        return np.array(json.loads(self.encoding))