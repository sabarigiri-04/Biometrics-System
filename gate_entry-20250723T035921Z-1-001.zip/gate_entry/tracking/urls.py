from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views
urlpatterns = [
    path('',views.index,name='index'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('details/',views.details,name='details'),
    path('face-entries/', views.face_entry_list, name='face_entry_list'),
    
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)