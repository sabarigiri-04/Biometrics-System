from django.shortcuts import render
from .models import FacultyEntry
from django.utils.timezone import now
import base64
from django.core.files.base import ContentFile
from .models import FacultyFaceEntry

from django.shortcuts import render
from .models import FacultyEntry, FacultyFaceEntry
from django.core.files.base import ContentFile
import base64

import face_recognition
from .models import FacultyFaceEntry, FacultyEntry
from django.core.files.base import ContentFile
from django.utils import timezone
import base64
from PIL import Image
import io

import base64
import io
from django.shortcuts import render
from django.core.files.base import ContentFile
from .models import FacultyEntry, FacultyFaceEntry
import face_recognition


from django.shortcuts import render
from .models import FacultyEntry, FacultyFaceEntry
from django.core.files.base import ContentFile
import base64

import face_recognition
from .models import FacultyFaceEntry, FacultyEntry
from django.core.files.base import ContentFile
from django.utils import timezone
import base64
from PIL import Image
import io

import base64
import io
from django.shortcuts import render
from django.core.files.base import ContentFile
from .models import FacultyEntry, FacultyFaceEntry
import face_recognition

import io, base64, json
import numpy as np
import face_recognition
from django.shortcuts import render
from django.core.files.base import ContentFile
from .models import FacultyFaceEntry, FacultyEntry

def index(request):
    if request.method == "POST":
        data_url = request.POST.get('captured_image')
        gate_entry = request.POST.get('gate_entry')
        purpose = request.POST.get('purpose')
        custom_purpose = request.POST.get('custom_purpose')

        if not data_url:
            return render(request, 'tracking/index.html', {'message': 'No image captured. Please try again.'})

        # Decode image
        try:
            _, imgstr = data_url.split(';base64,')
            image_data = base64.b64decode(imgstr)
        except Exception:
            return render(request, 'tracking/index.html', {'message': 'Invalid image format'})

        img = face_recognition.load_image_file(io.BytesIO(image_data))
        encs = face_recognition.face_encodings(img)
        if not encs:
            return render(request, 'tracking/index.html', {'message': 'No face detected. Try again.'})
        captured_enc = encs[0]

        # Load all known encodings
        known_entries = list(FacultyFaceEntry.objects.all())
        known_encs = [e.get_encoding_array() for e in known_entries]
        matches = face_recognition.compare_faces(known_encs, captured_enc, tolerance=0.5)

        if True in matches:
            matched = known_entries[matches.index(True)]
            # Create gate entry only
            FacultyEntry.objects.create(
                faculty_name=matched.faculty_name,
                staff_id=matched.staff_id,
                department=matched.department,
                gate_entry=gate_entry,
                purpose=(custom_purpose if purpose == "other" else purpose)
            )
            return render(request, 'tracking/index.html', {
                'message': f"Recognized {matched.staff_id}. Please confirm gate entry.",
                'auto_fill': matched
            })

        # New user registration
        name = request.POST.get('faculty_name')
        staff_id = request.POST.get('staff_id')
        department = request.POST.get('department')
        if not (name and staff_id and department):
            return render(request, 'tracking/index.html', {
                'message': 'Face not recognized. Please fill in all fields to register.',
                'register_mode': True
            })

        # Prevent duplicate staff ID
        if FacultyFaceEntry.objects.filter(staff_id=staff_id).exists():
            return render(request, 'tracking/index.html', {
                'message': 'Staff ID already exists. Face recognized as existing user.',
                'auto_fill': FacultyFaceEntry.objects.get(staff_id=staff_id)
            })

        # Save new user with encoding as JSON
        entry = FacultyFaceEntry(
            faculty_name=name,
            staff_id=staff_id,
            department=department,
            encoding=json.dumps(captured_enc.tolist())
        )
        entry.photo.save(f"{staff_id}.jpg", ContentFile(image_data))
        entry.save()

        # Log gate entry
        FacultyEntry.objects.create(
            faculty_name=name,
            staff_id=staff_id,
            department=department,
            gate_entry=gate_entry,
            purpose=(custom_purpose if purpose == "other" else purpose)
        )
        return render(request, 'tracking/index.html', {'message': 'New user registered and entry logged!'})

    return render(request, 'tracking/index.html')

from .models import FacultyFaceEntry

def face_entry_list(request):
    name_query = request.GET.get('name', '')
    dept_query = request.GET.get('department', '')

    entries = FacultyFaceEntry.objects.all()

    if name_query:
        entries = entries.filter(faculty_name__icontains=name_query)
    if dept_query:
        entries = entries.filter(department=dept_query)

    return render(request, 'tracking/face_entry_list.html', {'entries': entries})



from django.shortcuts import render
from django.utils.timezone import now
from django.db.models.functions import TruncDate
from .models import FacultyEntry

def dashboard(request):
    today_entries = FacultyEntry.objects.annotate(
        entry_date=TruncDate('entry_time')
    ).filter(
        entry_date=TruncDate(now())
    ).order_by('-entry_time')
    
    return render(request, 'tracking/dashboard.html', {'entries': today_entries})


def details(request):
    query = request.GET.get('search', '')
    department_filter = request.GET.get('department', '')

    entries = FacultyEntry.objects.all()

    if query:
        entries = entries.filter(
            faculty_name__icontains=query
        ) | entries.filter(
            staff_id__icontains=query
        )

    if department_filter:
        entries = entries.filter(department=department_filter)

    entries = entries.order_by('-entry_time')

    return render(request, 'tracking/details.html', {
        'entries': entries,
        'search': query,
        'department_filter': department_filter
    })

from .models import FacultyFaceEntry

def face_entry_list(request):
    name_query = request.GET.get('name', '')
    dept_query = request.GET.get('department', '')

    entries = FacultyFaceEntry.objects.all()

    if name_query:
        entries = entries.filter(faculty_name__icontains=name_query)
    if dept_query:
        entries = entries.filter(department=dept_query)

    return render(request, 'tracking/face_entry_list.html', {'entries': entries})



from django.shortcuts import render
from django.utils.timezone import now
from django.db.models.functions import TruncDate
from .models import FacultyEntry

def dashboard(request):
    today_entries = FacultyEntry.objects.annotate(
        entry_date=TruncDate('entry_time')
    ).filter(
        entry_date=TruncDate(now())
    ).order_by('-entry_time')
    
    return render(request, 'tracking/dashboard.html', {'entries': today_entries})


def details(request):
    query = request.GET.get('search', '')
    department_filter = request.GET.get('department', '')

    entries = FacultyEntry.objects.all()

    if query:
        entries = entries.filter(
            faculty_name__icontains=query
        ) | entries.filter(
            staff_id__icontains=query
        )

    if department_filter:
        entries = entries.filter(department=department_filter)

    entries = entries.order_by('-entry_time')

    return render(request, 'tracking/details.html', {
        'entries': entries,
        'search': query,
        'department_filter': department_filter
    })



